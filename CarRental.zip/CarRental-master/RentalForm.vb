﻿Option Explicit On
Option Strict On
Option Compare Binary
Public Class RentalForm

End Class
